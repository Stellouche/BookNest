package application;

import controller.AuthentificationController;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import view.CatalogueView;
import view.ConnexionView;
import view.CompteView;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Bienvenue sur BookNest");

        // Charger l'image
        Image image = new Image(getClass().getResourceAsStream("/img/affiche.png"));
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(250);
        imageView.setPreserveRatio(true);

        // Créer le label BookNest
        Label labelTitle = new Label("BookNest");
        labelTitle.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #000000;");

        // Boutons
        Button btnConnexion = new Button("Se connecter");
        Button btnCatalogue = new Button("Voir Catalogue");
        Button btnMonCompte = new Button("Mon Compte");
        Button btnDeconnexion = new Button("Se déconnecter");

        // Style des boutons
        String styleBouton = "-fx-background-color: #EFD8D3; "
                           + "-fx-text-fill: #000000; "
                           + "-fx-font-size: 14px; "
                           + "-fx-font-weight: bold; "
                           + "-fx-padding: 8 16 8 16; "
                           + "-fx-border-color: #FFCBCC; "
                           + "-fx-border-width: 2px; "
                           + "-fx-border-radius: 5px; "
                           + "-fx-background-radius: 5px;";

        btnConnexion.setStyle(styleBouton);
        btnCatalogue.setStyle(styleBouton);
        btnMonCompte.setStyle(styleBouton);
        btnDeconnexion.setStyle(styleBouton);

        // Actions
        btnConnexion.setOnAction(e -> {
            ConnexionView connexionView = new ConnexionView();
            try {
                connexionView.start(new Stage());
                primaryStage.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        btnCatalogue.setOnAction(e -> {
            CatalogueView catalogueView = new CatalogueView();
            try {
                catalogueView.start(new Stage());
                primaryStage.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        btnMonCompte.setOnAction(e -> {
            if (AuthentificationController.getUtilisateurConnecte() == null) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Information");
                alert.setHeaderText(null);
                alert.setContentText("Connectez-vous");
                alert.showAndWait();
            } else {
                CompteView compteView = new CompteView();
                try {
                    compteView.start(new Stage());
                    primaryStage.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        btnDeconnexion.setOnAction(e -> {
            if (AuthentificationController.getUtilisateurConnecte() != null) {
                AuthentificationController.deconnecter();
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Déconnexion");
                alert.setHeaderText(null);
                alert.setContentText("Vous êtes déconnecté.");
                alert.showAndWait();

                Main newMain = new Main();
                try {
                    newMain.start(new Stage());
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                primaryStage.close();
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Information");
                alert.setHeaderText(null);
                alert.setContentText("Aucun utilisateur n'est connecté.");
                alert.showAndWait();
            }
        });

        // Layout principal
        VBox layout = new VBox(15);
        layout.setAlignment(Pos.CENTER);

        // Ajouter le label BookNest, puis l'image, puis les boutons
        layout.getChildren().add(labelTitle);
        layout.getChildren().add(imageView);
        layout.getChildren().addAll(btnConnexion, btnCatalogue, btnMonCompte);

        // Ajouter le bouton de déconnexion uniquement si un utilisateur est connecté
        if (AuthentificationController.getUtilisateurConnecte() != null) {
            layout.getChildren().add(btnDeconnexion);
        }

        // Style du layout
        layout.setStyle(
            "-fx-background-color: #F4F0E3;" +
            "-fx-padding: 30;"
        );

        Scene scene = new Scene(layout, 400, 550);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
