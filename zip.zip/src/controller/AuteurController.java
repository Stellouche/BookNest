package controller;

import database.DatabaseConnection;
import model.Auteur;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AuteurController {
    public static List<Auteur> getTousLesAuteurs() {
        List<Auteur> auteurs = new ArrayList<>();
        String sql = "SELECT * FROM auteurs";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Auteur auteur = new Auteur(
                        rs.getInt("id"),
                        rs.getString("nom"),
                        rs.getString("prenom"),
                        rs.getString("date_naissance"),
                        rs.getString("description")
                );
                auteurs.add(auteur);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return auteurs;
    }
}
