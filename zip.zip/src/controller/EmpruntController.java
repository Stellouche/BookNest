package controller;

import database.DatabaseConnection;
import model.HistoriqueEmprunt;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class EmpruntController {

    /**
     * Vérifie si un livre est disponible.
     * Un livre est "non disponible" si la table 'emprunts' contient
     * une ligne avec 'date_retour' à NULL pour ce livre_id (ISBN).
     *
     * @param livreId identifiant du livre (ISBN, type VARCHAR)
     * @return true si disponible, false sinon
     */
    public static boolean estLivreDisponible(String livreId) {
        String sql = "SELECT * FROM emprunts WHERE livre_id = ? AND date_retour IS NULL";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, livreId);
            try (ResultSet rs = stmt.executeQuery()) {
                // S'il y a au moins une ligne, le livre est déjà emprunté
                return !rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // En cas d'erreur, on considère par défaut que le livre n'est pas disponible
            return false;
        }
    }

    /**
     * Emprunter un livre : crée une nouvelle ligne dans 'emprunts'
     * (date_emprunt = maintenant, date_retour = NULL).
     *
     * @param livreId       identifiant du livre (ISBN)
     * @param utilisateurId ID de l'utilisateur qui emprunte
     */
    public static void emprunterLivre(String livreId, int utilisateurId) {
        // Vérifier si le livre est disponible
        if (!estLivreDisponible(livreId)) {
            System.out.println("Le livre (ISBN=" + livreId + ") est déjà emprunté !");
            return;
        }

        String sql = "INSERT INTO emprunts (utilisateur_id, livre_id, date_emprunt, date_retour) " +
                     "VALUES (?, ?, ?, NULL)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, utilisateurId);
            stmt.setString(2, livreId);

            // Stocker la date/heure au format "yyyy-MM-dd HH:mm:ss"
            String dateEmprunt = LocalDateTime.now()
                                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            stmt.setString(3, dateEmprunt);

            stmt.executeUpdate();
            System.out.println("Livre emprunté avec succès (livreId=" + livreId + ", userId=" + utilisateurId + ") !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Retourner un livre : met à jour 'date_retour' avec la date/heure actuelle
     * sur la ligne où le livre est encore emprunté (date_retour IS NULL).
     *
     * @param livreId identifiant du livre (ISBN)
     */
    public static void retournerLivre(String livreId) {
        String sql = "UPDATE emprunts SET date_retour = ? " +
                     "WHERE livre_id = ? AND date_retour IS NULL";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String dateRetour = LocalDateTime.now()
                              .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            stmt.setString(1, dateRetour);
            stmt.setString(2, livreId);

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Livre retourné avec succès (livreId=" + livreId + ") !");
            } else {
                System.out.println("Aucun emprunt en cours pour ce livre !");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Récupère l'historique des emprunts (rendus ou non rendus) pour un utilisateur donné.
     * Jointure sur livres.isbn et auteurs.id.
     *
     * @param utilisateurId ID de l'utilisateur
     * @return Liste de l'historique des emprunts
     */
    public static List<HistoriqueEmprunt> getHistoriqueEmpruntsPar(int utilisateurId) {
        List<HistoriqueEmprunt> liste = new ArrayList<>();

        String sql = "SELECT e.livre_id, e.date_emprunt, e.date_retour, " +
                     "       l.titre AS livreTitre, " +
                     "       a.nom   AS auteurNom, " +
                     "       a.prenom AS auteurPrenom " +
                     "FROM emprunts e " +
                     "INNER JOIN livres l   ON l.isbn = e.livre_id " +   // Jointure sur l.isbn
                     "INNER JOIN auteurs a  ON a.id = l.auteur_id " +   // Jointure sur a.id
                     "WHERE e.utilisateur_id = ? " +
                     "ORDER BY e.date_emprunt DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, utilisateurId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String livreId     = rs.getString("livre_id");      // ISBN
                    String livreTitre  = rs.getString("livreTitre");
                    String auteurNom   = rs.getString("auteurNom");
                    String auteurPrenom= rs.getString("auteurPrenom");
                    String dateEmprunt = rs.getString("date_emprunt");
                    String dateRetour  = rs.getString("date_retour");   // peut être NULL

                    // On crée un objet HistoriqueEmprunt
                    liste.add(new HistoriqueEmprunt(
                            livreId,
                            livreTitre,
                            auteurNom,
                            auteurPrenom,
                            dateEmprunt,
                            dateRetour
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return liste;
    }
}
