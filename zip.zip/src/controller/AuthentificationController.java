package controller;

import database.DatabaseConnection;
import model.Utilisateur;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AuthentificationController {
    // Variable statique pour mémoriser l'utilisateur connecté
    private static Utilisateur utilisateurConnecte = null;

    public static boolean verifierConnexion(String email, String pin) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            // Requête pour vérifier l'email et le pin
            String sql = "SELECT * FROM utilisateurs WHERE email = ? AND pin = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, email);
            stmt.setString(2, pin);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                // Création de l'objet Utilisateur à partir des données récupérées
                // Remplacer "nom" par "login", pour correspondre à votre colonne en base
                utilisateurConnecte = new Utilisateur(
                        rs.getInt("id"),
                        rs.getString("login"), // <-- correction ici
                        rs.getString("email"),
                        rs.getString("pin")
                );
                return true;
            } else {
                // Aucune ligne trouvée, identifiants incorrects
                utilisateurConnecte = null;
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Getter pour récupérer l'utilisateur connecté
    public static Utilisateur getUtilisateurConnecte() {
        return utilisateurConnecte;
    }

    // Méthode pour se déconnecter si besoin
    public static void deconnecter() {
        utilisateurConnecte = null;
    }
}
