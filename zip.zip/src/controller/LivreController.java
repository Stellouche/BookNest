package controller;

import database.DatabaseConnection;
import model.Livre;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LivreController {

    /**
     * Récupère tous les livres depuis la base de données
     * en joignant la table auteurs pour reconstituer le nom complet de l'auteur.
     */
    public static List<Livre> getAllLivres() {
        List<Livre> liste = new ArrayList<>();
        String sql = "SELECT l.isbn, l.titre, a.nom, a.prenom "
                   + "FROM livres l "
                   + "JOIN auteurs a ON l.auteur_id = a.id";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String isbn = rs.getString("isbn");
                String titre = rs.getString("titre");
                // On concatène nom + prénom pour la colonne auteur
                String auteur = rs.getString("nom") + " " + rs.getString("prenom");

                liste.add(new Livre(isbn, titre, auteur));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return liste;
    }

    // Méthodes existantes pour gérer "disponible" (si vous en avez encore besoin)
    public static void emprunterLivre(int livreId) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "UPDATE livres SET disponible = false WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, livreId);
            stmt.executeUpdate();
            System.out.println("Livre emprunté avec succès !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void retournerLivre(int livreId) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "UPDATE livres SET disponible = true WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, livreId);
            stmt.executeUpdate();
            System.out.println("Livre retourné avec succès !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
