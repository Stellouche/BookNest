package view;

import application.Main;
import controller.AuthentificationController;
import controller.EmpruntController;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.HistoriqueEmprunt;
import model.Utilisateur;

public class CompteView extends Application {
    private Utilisateur utilisateur;
    private TableView<HistoriqueEmprunt> tableEmprunts = new TableView<>();

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Mon Compte");

        // Récupérer l'utilisateur connecté
        utilisateur = AuthentificationController.getUtilisateurConnecte();

        // ================== TOP : Titre ==================
        Label lblTitle = new Label("Mon Compte");
        lblTitle.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        VBox topBox = new VBox(lblTitle);
        topBox.setAlignment(Pos.CENTER);
        topBox.setPadding(new Insets(20));

        // ================== CENTER : infos + historique ==================
        VBox centerBox = new VBox(10);
        centerBox.setAlignment(Pos.TOP_LEFT);
        centerBox.setPadding(new Insets(20));

        if (utilisateur == null) {
            // Aucune connexion
            Label lblAucun = new Label("Aucun utilisateur connecté !");
            centerBox.getChildren().add(lblAucun);
        } else {
            // Informations de l'utilisateur
            Label lblInfo = new Label("Informations de l'utilisateur connecté :");
            // On supprime le label du nom (anciennement lblNom)

            // Seul l'email est affiché
            Label lblEmail = new Label("Email : " + utilisateur.getEmail());

            Label lblHistorique = new Label("Historique de mes emprunts :");

            // Colonnes de la table
            TableColumn<HistoriqueEmprunt, String> colTitre = new TableColumn<>("Titre");
            colTitre.setCellValueFactory(data -> data.getValue().titreProperty());

            TableColumn<HistoriqueEmprunt, String> colAuteur = new TableColumn<>("Auteur");
            colAuteur.setCellValueFactory(data -> {
                String nom  = data.getValue().auteurNomProperty().get();
                String prenom = data.getValue().auteurPrenomProperty().get();
                return new javafx.beans.property.SimpleStringProperty(nom + " " + prenom);
            });

            TableColumn<HistoriqueEmprunt, String> colDateEmprunt = new TableColumn<>("Date Emprunt");
            colDateEmprunt.setCellValueFactory(data -> data.getValue().dateEmpruntProperty());

            TableColumn<HistoriqueEmprunt, String> colDateRetour = new TableColumn<>("Date Retour");
            colDateRetour.setCellValueFactory(data -> data.getValue().dateRetourProperty());

            tableEmprunts.getColumns().addAll(colTitre, colAuteur, colDateEmprunt, colDateRetour);
            tableEmprunts.setItems(getHistoriqueEmprunts());

            // ================== STYLISER LE TABLEAU ==================
            tableEmprunts.setStyle(
                "-fx-background-color: #F4F0E3;" +
                "-fx-control-inner-background: #F4F0E3;" +
                "-fx-table-cell-border-color: #FFCBCC;" +
                "-fx-table-header-border-color: #FFCBCC;" +
                "-fx-base: #EFD8D3;" +
                "-fx-font-size: 14px;"
            );

            colTitre.setPrefWidth(150);
            colAuteur.setPrefWidth(120);
            colDateEmprunt.setPrefWidth(120);
            colDateRetour.setPrefWidth(120);

            // On n'ajoute plus de label pour le nom
            centerBox.getChildren().addAll(
                lblInfo, lblEmail,
                lblHistorique, tableEmprunts
            );
        }

        // ================== BOTTOM : bouton Retour au Menu ==================
        Button btnRetourMenu = new Button("Retour au Menu");
        String styleBouton = "-fx-background-color: #EFD8D3; "
                           + "-fx-text-fill: #000000; "
                           + "-fx-font-size: 14px; "
                           + "-fx-font-weight: bold; "
                           + "-fx-padding: 8 16 8 16; "
                           + "-fx-border-color: #FFCBCC; "
                           + "-fx-border-width: 2px; "
                           + "-fx-border-radius: 5px; "
                           + "-fx-background-radius: 5px;";
        btnRetourMenu.setStyle(styleBouton);

        btnRetourMenu.setOnAction(e -> {
            primaryStage.close();
            Main mainApp = new Main();
            try {
                mainApp.start(new Stage());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        HBox bottomBox = new HBox(btnRetourMenu);
        bottomBox.setAlignment(Pos.CENTER_RIGHT);
        bottomBox.setPadding(new Insets(10));

        // ================== ASSEMBLAGE : BorderPane ==================
        BorderPane root = new BorderPane();
        root.setTop(topBox);
        root.setCenter(centerBox);
        root.setBottom(bottomBox);

        root.setStyle("-fx-background-color: #F4F0E3;");

        Scene scene = new Scene(root, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private ObservableList<HistoriqueEmprunt> getHistoriqueEmprunts() {
        if (utilisateur == null) {
            return FXCollections.emptyObservableList();
        }
        return FXCollections.observableArrayList(
            EmpruntController.getHistoriqueEmpruntsPar(utilisateur.getId())
        );
    }

    public static void main(String[] args) {
        launch(args);
    }
}
