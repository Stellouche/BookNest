package view;

import application.Main;
import controller.AuthentificationController;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class ConnexionView extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Connexion - BookNest");

        // ================= TOP : Label + Image =================
        Label labelTitle = new Label("Connectez-vous !");
        labelTitle.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #000;");

        Image image = new Image(getClass().getResourceAsStream("/img/log.png"));
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(150);
        imageView.setPreserveRatio(true);

        VBox topBox = new VBox(10, labelTitle, imageView);
        topBox.setAlignment(Pos.CENTER);

        // ================= CENTER : Formulaire =================
        Label emailLabel = new Label("Email :");
        TextField emailField = new TextField();
        // Limiter la largeur du champ
        emailField.setMaxWidth(200);

        Label pinLabel = new Label("PIN :");
        PasswordField pinField = new PasswordField();
        // Limiter la largeur du champ
        pinField.setMaxWidth(200);

        Label message = new Label();

        Button btnConnexion = new Button("Se connecter");

        // Style bouton
        String styleBouton = "-fx-background-color: #EFD8D3; "
                           + "-fx-text-fill: #000000; "
                           + "-fx-font-size: 14px; "
                           + "-fx-font-weight: bold; "
                           + "-fx-padding: 8 16 8 16; "
                           + "-fx-border-color: #FFCBCC; "
                           + "-fx-border-width: 2px; "
                           + "-fx-border-radius: 5px; "
                           + "-fx-background-radius: 5px;";
        btnConnexion.setStyle(styleBouton);

        // Action du bouton Se connecter
        btnConnexion.setOnAction(e -> {
            String email = emailField.getText();
            String pin = pinField.getText();

            if (AuthentificationController.verifierConnexion(email, pin)) {
                message.setText("Connexion réussie !");
                // Rediriger vers le catalogue
                CatalogueView catalogueView = new CatalogueView();
                try {
                    catalogueView.start(new Stage());
                    primaryStage.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            } else {
                message.setText("Identifiants incorrects !");
            }
        });

        // VBox pour le formulaire
        VBox formBox = new VBox(8,
                emailLabel, emailField,
                pinLabel, pinField,
                btnConnexion,
                message
        );
        formBox.setAlignment(Pos.CENTER);

        // ================= BOTTOM : Bouton Retour au Menu aligné à droite =================
        Button btnRetourMenu = new Button("Retour au Menu");
        btnRetourMenu.setStyle(styleBouton);
        btnRetourMenu.setOnAction(e -> {
            primaryStage.close();
            Main mainApp = new Main();
            try {
                mainApp.start(new Stage());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        HBox bottomBox = new HBox(btnRetourMenu);
        bottomBox.setAlignment(Pos.CENTER_RIGHT);
        bottomBox.setPadding(new Insets(10));

        // ================= ASSEMBLAGE dans un BorderPane =================
        BorderPane root = new BorderPane();
        root.setTop(topBox);
        root.setCenter(formBox);
        root.setBottom(bottomBox);

        // Style global
        root.setStyle("-fx-background-color: #F4F0E3;");
        BorderPane.setMargin(topBox, new Insets(20));
        BorderPane.setMargin(formBox, new Insets(10));

        Scene scene = new Scene(root, 400, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
