package view;

import controller.AuteurController;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Auteur;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class AuteurView extends Application {
    private TableView<Auteur> table = new TableView<>();

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Liste des Auteurs");

        TableColumn<Auteur, String> nomCol = new TableColumn<>("Nom");
        nomCol.setCellValueFactory(new PropertyValueFactory<>("nom"));

        TableColumn<Auteur, String> prenomCol = new TableColumn<>("Prénom");
        prenomCol.setCellValueFactory(new PropertyValueFactory<>("prenom"));

        TableColumn<Auteur, String> dateNaissanceCol = new TableColumn<>("Date de Naissance");
        dateNaissanceCol.setCellValueFactory(new PropertyValueFactory<>("dateNaissance"));

        TableColumn<Auteur, String> descriptionCol = new TableColumn<>("Description");
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));

        table.getColumns().addAll(nomCol, prenomCol, dateNaissanceCol, descriptionCol);
        table.setItems(getAuteurs());

        VBox vbox = new VBox(table);
        Scene scene = new Scene(vbox, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private ObservableList<Auteur> getAuteurs() {
        return FXCollections.observableArrayList(AuteurController.getTousLesAuteurs());
    }

    public static void main(String[] args) {
        launch(args);
    }
}
