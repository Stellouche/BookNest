package view;

import application.Main;
import controller.AuthentificationController;
import controller.EmpruntController;
import controller.LivreController;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Livre;
import model.Utilisateur;

public class CatalogueView extends Application {
    private TableView<Livre> table = new TableView<>();

    // Liste brute (non filtrée) qu'on récupère depuis la base
    private FilteredList<Livre> filteredData;
    private TextField searchField = new TextField();

    // Couleurs demandées
    private static final String COLOR_VERT = "#C1D5AF";     // Vert pastel
    private static final String COLOR_BORDEAUX = "#84033C"; // Rouge bordeaux

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Catalogue des Livres");

        // =========== TOP : Titre ================
        Label lblTitle = new Label("Catalogue des Livres");
        lblTitle.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        VBox topBox = new VBox(lblTitle);
        topBox.setAlignment(Pos.CENTER);
        topBox.setPadding(new Insets(20));

        // =========== CENTER : Barre de recherche + Table ================
        searchField.setPromptText("Rechercher un livre ou un auteur...");
        searchField.setMaxWidth(300);
        searchField.setStyle("-fx-background-color: #FFF; "
                           + "-fx-font-size: 14px; "
                           + "-fx-border-color: #FFCBCC; "
                           + "-fx-border-width: 2px; "
                           + "-fx-border-radius: 5px; "
                           + "-fx-background-radius: 5px; "
                           + "-fx-padding: 5 10 5 10;");

        TableColumn<Livre, String> titreCol = new TableColumn<>("Titre");
        titreCol.setCellValueFactory(data -> data.getValue().titreProperty());
        titreCol.setPrefWidth(200);

        TableColumn<Livre, String> auteurCol = new TableColumn<>("Auteur");
        auteurCol.setCellValueFactory(data -> data.getValue().auteurProperty());
        auteurCol.setPrefWidth(180);

        TableColumn<Livre, String> dispoCol = new TableColumn<>("Disponibilité");
        dispoCol.setPrefWidth(120);

        // La valeur interne (Disponible / Indisponible) :
        dispoCol.setCellValueFactory(cellData -> {
            String isbn = cellData.getValue().getIsbn();
            boolean disponible = EmpruntController.estLivreDisponible(isbn);
            return new SimpleStringProperty(disponible ? "Disponible" : "Indisponible");
        });

        // CellFactory pour afficher un point coloré au lieu du texte
        dispoCol.setCellFactory(column -> new TableCell<Livre, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);

                if (empty || item == null) {
                    setText(null);
                    setStyle("");
                } else {
                    // On affiche un point (●) et on le colore
                    setText("●");
                    setStyle("-fx-alignment: CENTER; -fx-font-size: 16px;");

                    if ("Disponible".equals(item)) {
                        // Vert pastel
                        setStyle(getStyle() + "-fx-text-fill: " + COLOR_VERT + ";");
                    } else {
                        // Bordeaux
                        setStyle(getStyle() + "-fx-text-fill: " + COLOR_BORDEAUX + ";");
                    }
                }
            }
        });

        table.getColumns().addAll(titreCol, auteurCol, dispoCol);

        // Style du tableau en pastel
        table.setStyle(
            "-fx-background-color: #F4F0E3;"
          + "-fx-control-inner-background: #F4F0E3;"
          + "-fx-table-cell-border-color: #FFCBCC;"
          + "-fx-table-header-border-color: #FFCBCC;"
          + "-fx-font-size: 14px;"
        );

        // Charger les livres depuis la base
        loadLivresFromDB();

        // Filtrage
        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            filteredData.setPredicate(livre -> {
                if (newVal == null || newVal.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newVal.toLowerCase();
                if (livre.getTitre().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                } else if (livre.getAuteur().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                }
                return false;
            });
        });

        VBox centerBox = new VBox(10, searchField, table);
        centerBox.setAlignment(Pos.TOP_CENTER);
        centerBox.setPadding(new Insets(20));

        // =========== BOTTOM : Boutons ================
        Button btnEmprunter = new Button("Emprunter");
        Button btnRetour = new Button("Retour (Livre)");
        Button btnMenuPrincipal = new Button("Retour au Menu");

        // Style commun aux boutons
        String styleBouton = "-fx-background-color: #EFD8D3; "
                           + "-fx-text-fill: #000000; "
                           + "-fx-font-size: 14px; "
                           + "-fx-font-weight: bold; "
                           + "-fx-padding: 8 16 8 16; "
                           + "-fx-border-color: #FFCBCC; "
                           + "-fx-border-width: 2px; "
                           + "-fx-border-radius: 5px; "
                           + "-fx-background-radius: 5px;";

        btnEmprunter.setStyle(styleBouton);
        btnRetour.setStyle(styleBouton);
        btnMenuPrincipal.setStyle(styleBouton);

        // Actions
        btnEmprunter.setOnAction(e -> {
            Livre selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                Utilisateur userConnecte = AuthentificationController.getUtilisateurConnecte();
                if (userConnecte == null) {
                    showAlert("Erreur", "Vous devez être connecté pour emprunter un livre.");
                } else {
                    if (EmpruntController.estLivreDisponible(selected.getIsbn())) {
                        EmpruntController.emprunterLivre(selected.getIsbn(), userConnecte.getId());
                        showAlert("Succès", "Le livre a été emprunté avec succès !");
                        table.refresh();
                    } else {
                        showAlert("Information", "Le livre est déjà emprunté !");
                    }
                }
            }
        });

        btnRetour.setOnAction(e -> {
            Livre selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                if (!EmpruntController.estLivreDisponible(selected.getIsbn())) {
                    EmpruntController.retournerLivre(selected.getIsbn());
                    showAlert("Succès", "Le livre a été retourné avec succès !");
                    table.refresh();
                } else {
                    showAlert("Information", "Ce livre est déjà disponible !");
                }
            }
        });

        btnMenuPrincipal.setOnAction(e -> {
            primaryStage.close();
            Main mainApp = new Main();
            try {
                mainApp.start(new Stage());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        HBox bottomBox = new HBox(10, btnEmprunter, btnRetour, btnMenuPrincipal);
        bottomBox.setAlignment(Pos.CENTER);
        bottomBox.setPadding(new Insets(10));

        // =========== ASSEMBLAGE : BorderPane ================
        BorderPane root = new BorderPane();
        root.setTop(topBox);
        root.setCenter(centerBox);
        root.setBottom(bottomBox);

        // Fond pastel global
        root.setStyle("-fx-background-color: #F4F0E3;");

        Scene scene = new Scene(root, 600, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void loadLivresFromDB() {
        // Récupère tous les livres
        ObservableList<Livre> masterData = FXCollections.observableArrayList(LivreController.getAllLivres());
        // Crée la FilteredList
        filteredData = new FilteredList<>(masterData, p -> true);
        // Crée la SortedList
        SortedList<Livre> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(table.comparatorProperty());
        // Assigne sortedData à la table
        table.setItems(sortedData);
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
