package model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Livre {
    private String isbn;
    private final StringProperty titre;
    private final StringProperty auteur;

    public Livre(String isbn, String titre, String auteur) {
        this.isbn = isbn;
        this.titre = new SimpleStringProperty(titre);
        this.auteur = new SimpleStringProperty(auteur);
    }

    public String getIsbn() {
        return isbn;
    }

    // Getters pour la valeur String (pas le Property)
    public String getTitre() {
        return titre.get();
    }

    public String getAuteur() {
        return auteur.get();
    }

    // Propriétés existantes (conservées)
    public StringProperty titreProperty() {
        return titre;
    }

    public StringProperty auteurProperty() {
        return auteur;
    }
}
