package model;

public class Auteur {
    private int id;
    private String nom;
    private String prenom;
    private String dateNaissance;
    private String description;

    public Auteur(int id, String nom, String prenom, String dateNaissance, String description) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.dateNaissance = dateNaissance;
        this.description = description;
    }

    // Getters et setters
    public int getId() { return id; }
    public String getNom() { return nom; }
    public String getPrenom() { return prenom; }
    public String getDateNaissance() { return dateNaissance; }
    public String getDescription() { return description; }
}
