package model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class HistoriqueEmprunt {
    private final StringProperty livreId;      // l.isbn
    private final StringProperty titre;        // livreTitre
    private final StringProperty auteurNom;    // auteurNom
    private final StringProperty auteurPrenom; // auteurPrenom
    private final StringProperty dateEmprunt;
    private final StringProperty dateRetour;

    public HistoriqueEmprunt(String livreId,
                             String titre,
                             String auteurNom,
                             String auteurPrenom,
                             String dateEmprunt,
                             String dateRetour) {

        this.livreId = new SimpleStringProperty(livreId == null ? "" : livreId);
        this.titre   = new SimpleStringProperty(titre == null ? "" : titre);
        this.auteurNom = new SimpleStringProperty(auteurNom == null ? "" : auteurNom);
        this.auteurPrenom = new SimpleStringProperty(auteurPrenom == null ? "" : auteurPrenom);
        this.dateEmprunt = new SimpleStringProperty(dateEmprunt == null ? "" : dateEmprunt);
        this.dateRetour  = new SimpleStringProperty(dateRetour == null ? "Non rendu" : dateRetour);
    }

    public StringProperty livreIdProperty() {
        return livreId;
    }
    public StringProperty titreProperty() {
        return titre;
    }
    public StringProperty auteurNomProperty() {
        return auteurNom;
    }
    public StringProperty auteurPrenomProperty() {
        return auteurPrenom;
    }
    public StringProperty dateEmpruntProperty() {
        return dateEmprunt;
    }
    public StringProperty dateRetourProperty() {
        return dateRetour;
    }
}
