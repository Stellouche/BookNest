package model;

public class Utilisateur {
    private int id;
    private String nom;
    private String email;
    private String pin; // Code PIN à 4 chiffres pour la connexion

    public Utilisateur(int id, String nom, String email, String pin) {
        this.id = id;
        this.nom = nom;
        this.email = email;
        this.pin = pin;
    }

    // Getters et setters
    public int getId() { return id; }
    public String getNom() { return nom; }
    public String getEmail() { return email; }
    public boolean verifierPin(String saisie) { return this.pin.equals(saisie); }
}
